﻿namespace Milestone_2_PRG281
{
    partial class menuform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(menuform));
            this.TopPanel = new System.Windows.Forms.Panel();
            this.BC_Cafe_Lbl = new System.Windows.Forms.Label();
            this.Sandwich = new System.Windows.Forms.GroupBox();
            this.Qty1 = new System.Windows.Forms.Label();
            this.TxtBox2 = new System.Windows.Forms.TextBox();
            this.TxtBox3 = new System.Windows.Forms.TextBox();
            this.TxtBox4 = new System.Windows.Forms.TextBox();
            this.TxtBox6 = new System.Windows.Forms.TextBox();
            this.TxtBox5 = new System.Windows.Forms.TextBox();
            this.TxtBox1 = new System.Windows.Forms.TextBox();
            this.Sandwich_6 = new System.Windows.Forms.CheckBox();
            this.Sandwich_5 = new System.Windows.Forms.CheckBox();
            this.Sandwich_4 = new System.Windows.Forms.CheckBox();
            this.Sandwich_3 = new System.Windows.Forms.CheckBox();
            this.Sandwich_2 = new System.Windows.Forms.CheckBox();
            this.Sandwich_1 = new System.Windows.Forms.CheckBox();
            this.Sandwich_Box = new System.Windows.Forms.PictureBox();
            this.Burgers = new System.Windows.Forms.GroupBox();
            this.Qty2 = new System.Windows.Forms.Label();
            this.TxtBox8 = new System.Windows.Forms.TextBox();
            this.TxtBox9 = new System.Windows.Forms.TextBox();
            this.TxtBox10 = new System.Windows.Forms.TextBox();
            this.TxtBox12 = new System.Windows.Forms.TextBox();
            this.TxtBox11 = new System.Windows.Forms.TextBox();
            this.TxtBox7 = new System.Windows.Forms.TextBox();
            this.Burger_6 = new System.Windows.Forms.CheckBox();
            this.Burger_5 = new System.Windows.Forms.CheckBox();
            this.Burger_4 = new System.Windows.Forms.CheckBox();
            this.Burger_3 = new System.Windows.Forms.CheckBox();
            this.Burger_2 = new System.Windows.Forms.CheckBox();
            this.Burger_1 = new System.Windows.Forms.CheckBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Drinks = new System.Windows.Forms.GroupBox();
            this.Qty3 = new System.Windows.Forms.Label();
            this.TxtBox14 = new System.Windows.Forms.TextBox();
            this.TxtBox15 = new System.Windows.Forms.TextBox();
            this.TxtBox16 = new System.Windows.Forms.TextBox();
            this.TxtBox18 = new System.Windows.Forms.TextBox();
            this.TxtBox17 = new System.Windows.Forms.TextBox();
            this.TxtBox13 = new System.Windows.Forms.TextBox();
            this.Beverage_6 = new System.Windows.Forms.CheckBox();
            this.Beverage_5 = new System.Windows.Forms.CheckBox();
            this.Beverage_4 = new System.Windows.Forms.CheckBox();
            this.Beverage_3 = new System.Windows.Forms.CheckBox();
            this.Beverage_2 = new System.Windows.Forms.CheckBox();
            this.Beverage_1 = new System.Windows.Forms.CheckBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Btn_Reset = new System.Windows.Forms.Button();
            this.Btn_PlaceOrder = new System.Windows.Forms.Button();
            this.Lbl_Total = new System.Windows.Forms.Label();
            this.tot_txtbox = new System.Windows.Forms.TextBox();
            this.Btn_Exit = new System.Windows.Forms.Button();
            this.Receipt = new System.Windows.Forms.RichTextBox();
            this.tax_txtbox = new System.Windows.Forms.TextBox();
            this.Tax_Lbl = new System.Windows.Forms.Label();
            this.subtot_txtbox = new System.Windows.Forms.TextBox();
            this.Subtotal_lbl = new System.Windows.Forms.Label();
            this.TopPanel.SuspendLayout();
            this.Sandwich.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Sandwich_Box)).BeginInit();
            this.Burgers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.Drinks.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // TopPanel
            // 
            this.TopPanel.BackColor = System.Drawing.Color.DarkOrange;
            this.TopPanel.Controls.Add(this.BC_Cafe_Lbl);
            this.TopPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.TopPanel.Location = new System.Drawing.Point(0, 0);
            this.TopPanel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TopPanel.Name = "TopPanel";
            this.TopPanel.Size = new System.Drawing.Size(1145, 38);
            this.TopPanel.TabIndex = 2;
            // 
            // BC_Cafe_Lbl
            // 
            this.BC_Cafe_Lbl.AutoSize = true;
            this.BC_Cafe_Lbl.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BC_Cafe_Lbl.Location = new System.Drawing.Point(387, 0);
            this.BC_Cafe_Lbl.Name = "BC_Cafe_Lbl";
            this.BC_Cafe_Lbl.Size = new System.Drawing.Size(373, 31);
            this.BC_Cafe_Lbl.TabIndex = 0;
            this.BC_Cafe_Lbl.Text = "Welcome to the BC cafe menu!";
            // 
            // Sandwich
            // 
            this.Sandwich.BackColor = System.Drawing.Color.OrangeRed;
            this.Sandwich.Controls.Add(this.Qty1);
            this.Sandwich.Controls.Add(this.TxtBox2);
            this.Sandwich.Controls.Add(this.TxtBox3);
            this.Sandwich.Controls.Add(this.TxtBox4);
            this.Sandwich.Controls.Add(this.TxtBox6);
            this.Sandwich.Controls.Add(this.TxtBox5);
            this.Sandwich.Controls.Add(this.TxtBox1);
            this.Sandwich.Controls.Add(this.Sandwich_6);
            this.Sandwich.Controls.Add(this.Sandwich_5);
            this.Sandwich.Controls.Add(this.Sandwich_4);
            this.Sandwich.Controls.Add(this.Sandwich_3);
            this.Sandwich.Controls.Add(this.Sandwich_2);
            this.Sandwich.Controls.Add(this.Sandwich_1);
            this.Sandwich.Controls.Add(this.Sandwich_Box);
            this.Sandwich.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Sandwich.Location = new System.Drawing.Point(12, 43);
            this.Sandwich.Name = "Sandwich";
            this.Sandwich.Size = new System.Drawing.Size(379, 321);
            this.Sandwich.TabIndex = 3;
            this.Sandwich.TabStop = false;
            this.Sandwich.Text = "Sandwiches:";
            this.Sandwich.Enter += new System.EventHandler(this.Sandwich_Enter);
            // 
            // Qty1
            // 
            this.Qty1.AutoSize = true;
            this.Qty1.Location = new System.Drawing.Point(296, 103);
            this.Qty1.Name = "Qty1";
            this.Qty1.Size = new System.Drawing.Size(50, 24);
            this.Qty1.TabIndex = 27;
            this.Qty1.Text = "Qty:";
            // 
            // TxtBox2
            // 
            this.TxtBox2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TxtBox2.Location = new System.Drawing.Point(296, 168);
            this.TxtBox2.Name = "TxtBox2";
            this.TxtBox2.Size = new System.Drawing.Size(66, 26);
            this.TxtBox2.TabIndex = 26;
            this.TxtBox2.Text = "0";
            this.TxtBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TxtBox2.Validated += new System.EventHandler(this.Validated);
            // 
            // TxtBox3
            // 
            this.TxtBox3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TxtBox3.Location = new System.Drawing.Point(296, 197);
            this.TxtBox3.Name = "TxtBox3";
            this.TxtBox3.Size = new System.Drawing.Size(66, 26);
            this.TxtBox3.TabIndex = 25;
            this.TxtBox3.Text = "0";
            this.TxtBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TxtBox3.Validated += new System.EventHandler(this.Validated);
            // 
            // TxtBox4
            // 
            this.TxtBox4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TxtBox4.Location = new System.Drawing.Point(296, 226);
            this.TxtBox4.Name = "TxtBox4";
            this.TxtBox4.Size = new System.Drawing.Size(66, 26);
            this.TxtBox4.TabIndex = 24;
            this.TxtBox4.Text = "0";
            this.TxtBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TxtBox4.Validated += new System.EventHandler(this.Validated);
            // 
            // TxtBox6
            // 
            this.TxtBox6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TxtBox6.Location = new System.Drawing.Point(296, 285);
            this.TxtBox6.Name = "TxtBox6";
            this.TxtBox6.Size = new System.Drawing.Size(66, 26);
            this.TxtBox6.TabIndex = 23;
            this.TxtBox6.Text = "0";
            this.TxtBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TxtBox6.Validated += new System.EventHandler(this.Validated);
            // 
            // TxtBox5
            // 
            this.TxtBox5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TxtBox5.Location = new System.Drawing.Point(296, 255);
            this.TxtBox5.Name = "TxtBox5";
            this.TxtBox5.Size = new System.Drawing.Size(66, 26);
            this.TxtBox5.TabIndex = 22;
            this.TxtBox5.Text = "0";
            this.TxtBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TxtBox5.Validated += new System.EventHandler(this.Validated);
            // 
            // TxtBox1
            // 
            this.TxtBox1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TxtBox1.Location = new System.Drawing.Point(296, 137);
            this.TxtBox1.Name = "TxtBox1";
            this.TxtBox1.Size = new System.Drawing.Size(66, 26);
            this.TxtBox1.TabIndex = 20;
            this.TxtBox1.Text = "0";
            this.TxtBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TxtBox1.Validated += new System.EventHandler(this.Validated);
            // 
            // Sandwich_6
            // 
            this.Sandwich_6.AutoSize = true;
            this.Sandwich_6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Sandwich_6.Location = new System.Drawing.Point(6, 287);
            this.Sandwich_6.Name = "Sandwich_6";
            this.Sandwich_6.Size = new System.Drawing.Size(169, 23);
            this.Sandwich_6.TabIndex = 5;
            this.Sandwich_6.Text = "Supreme Toast - R55";
            this.Sandwich_6.UseVisualStyleBackColor = true;
            this.Sandwich_6.CheckedChanged += new System.EventHandler(this.Sandwich_6_CheckedChanged);
            // 
            // Sandwich_5
            // 
            this.Sandwich_5.AutoSize = true;
            this.Sandwich_5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Sandwich_5.Location = new System.Drawing.Point(6, 258);
            this.Sandwich_5.Name = "Sandwich_5";
            this.Sandwich_5.Size = new System.Drawing.Size(225, 23);
            this.Sandwich_5.TabIndex = 4;
            this.Sandwich_5.Text = "Toasted Chicken Mayo - R50";
            this.Sandwich_5.UseVisualStyleBackColor = true;
            this.Sandwich_5.CheckedChanged += new System.EventHandler(this.Sandwich_5_CheckedChanged);
            // 
            // Sandwich_4
            // 
            this.Sandwich_4.AutoSize = true;
            this.Sandwich_4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Sandwich_4.Location = new System.Drawing.Point(6, 229);
            this.Sandwich_4.Name = "Sandwich_4";
            this.Sandwich_4.Size = new System.Drawing.Size(205, 23);
            this.Sandwich_4.TabIndex = 3;
            this.Sandwich_4.Text = "Garlic Cheese Toast - R35";
            this.Sandwich_4.UseVisualStyleBackColor = true;
            this.Sandwich_4.CheckedChanged += new System.EventHandler(this.Sandwich_4_CheckedChanged);
            // 
            // Sandwich_3
            // 
            this.Sandwich_3.AutoSize = true;
            this.Sandwich_3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Sandwich_3.Location = new System.Drawing.Point(6, 200);
            this.Sandwich_3.Name = "Sandwich_3";
            this.Sandwich_3.Size = new System.Drawing.Size(240, 23);
            this.Sandwich_3.TabIndex = 2;
            this.Sandwich_3.Text = "Toasted Ham and Cheese - R40";
            this.Sandwich_3.UseVisualStyleBackColor = true;
            this.Sandwich_3.CheckedChanged += new System.EventHandler(this.Sandwich_3_CheckedChanged);
            // 
            // Sandwich_2
            // 
            this.Sandwich_2.AutoSize = true;
            this.Sandwich_2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Sandwich_2.Location = new System.Drawing.Point(6, 171);
            this.Sandwich_2.Name = "Sandwich_2";
            this.Sandwich_2.Size = new System.Drawing.Size(258, 23);
            this.Sandwich_2.TabIndex = 1;
            this.Sandwich_2.Text = "Toasted Cheese and Tomato - R40";
            this.Sandwich_2.UseVisualStyleBackColor = true;
            this.Sandwich_2.CheckedChanged += new System.EventHandler(this.Sandwich_2_CheckedChanged);
            // 
            // Sandwich_1
            // 
            this.Sandwich_1.AutoSize = true;
            this.Sandwich_1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Sandwich_1.Location = new System.Drawing.Point(6, 142);
            this.Sandwich_1.Name = "Sandwich_1";
            this.Sandwich_1.Size = new System.Drawing.Size(176, 23);
            this.Sandwich_1.TabIndex = 0;
            this.Sandwich_1.Text = "Toasted Cheese - R30";
            this.Sandwich_1.UseVisualStyleBackColor = true;
            this.Sandwich_1.CheckedChanged += new System.EventHandler(this.Sandwich_1_CheckedChanged);
            // 
            // Sandwich_Box
            // 
            this.Sandwich_Box.Image = ((System.Drawing.Image)(resources.GetObject("Sandwich_Box.Image")));
            this.Sandwich_Box.Location = new System.Drawing.Point(102, 31);
            this.Sandwich_Box.Name = "Sandwich_Box";
            this.Sandwich_Box.Size = new System.Drawing.Size(134, 103);
            this.Sandwich_Box.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Sandwich_Box.TabIndex = 6;
            this.Sandwich_Box.TabStop = false;
            // 
            // Burgers
            // 
            this.Burgers.BackColor = System.Drawing.Color.OrangeRed;
            this.Burgers.Controls.Add(this.Qty2);
            this.Burgers.Controls.Add(this.TxtBox8);
            this.Burgers.Controls.Add(this.TxtBox9);
            this.Burgers.Controls.Add(this.TxtBox10);
            this.Burgers.Controls.Add(this.TxtBox12);
            this.Burgers.Controls.Add(this.TxtBox11);
            this.Burgers.Controls.Add(this.TxtBox7);
            this.Burgers.Controls.Add(this.Burger_6);
            this.Burgers.Controls.Add(this.Burger_5);
            this.Burgers.Controls.Add(this.Burger_4);
            this.Burgers.Controls.Add(this.Burger_3);
            this.Burgers.Controls.Add(this.Burger_2);
            this.Burgers.Controls.Add(this.Burger_1);
            this.Burgers.Controls.Add(this.pictureBox1);
            this.Burgers.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Burgers.Location = new System.Drawing.Point(12, 370);
            this.Burgers.Name = "Burgers";
            this.Burgers.Size = new System.Drawing.Size(379, 315);
            this.Burgers.TabIndex = 5;
            this.Burgers.TabStop = false;
            this.Burgers.Text = "Burgers:";
            // 
            // Qty2
            // 
            this.Qty2.AutoSize = true;
            this.Qty2.Location = new System.Drawing.Point(273, 103);
            this.Qty2.Name = "Qty2";
            this.Qty2.Size = new System.Drawing.Size(50, 24);
            this.Qty2.TabIndex = 38;
            this.Qty2.Text = "Qty:";
            // 
            // TxtBox8
            // 
            this.TxtBox8.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TxtBox8.Location = new System.Drawing.Point(278, 171);
            this.TxtBox8.Name = "TxtBox8";
            this.TxtBox8.Size = new System.Drawing.Size(63, 26);
            this.TxtBox8.TabIndex = 37;
            this.TxtBox8.Text = "0";
            this.TxtBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TxtBox8.Validated += new System.EventHandler(this.Validated);
            // 
            // TxtBox9
            // 
            this.TxtBox9.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TxtBox9.Location = new System.Drawing.Point(278, 200);
            this.TxtBox9.Name = "TxtBox9";
            this.TxtBox9.Size = new System.Drawing.Size(63, 26);
            this.TxtBox9.TabIndex = 36;
            this.TxtBox9.Text = "0";
            this.TxtBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TxtBox9.Validated += new System.EventHandler(this.Validated);
            // 
            // TxtBox10
            // 
            this.TxtBox10.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TxtBox10.Location = new System.Drawing.Point(278, 229);
            this.TxtBox10.Name = "TxtBox10";
            this.TxtBox10.Size = new System.Drawing.Size(63, 26);
            this.TxtBox10.TabIndex = 35;
            this.TxtBox10.Text = "0";
            this.TxtBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TxtBox10.Validated += new System.EventHandler(this.Validated);
            // 
            // TxtBox12
            // 
            this.TxtBox12.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TxtBox12.Location = new System.Drawing.Point(278, 288);
            this.TxtBox12.Name = "TxtBox12";
            this.TxtBox12.Size = new System.Drawing.Size(63, 26);
            this.TxtBox12.TabIndex = 34;
            this.TxtBox12.Text = "0";
            this.TxtBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TxtBox12.Validated += new System.EventHandler(this.Validated);
            // 
            // TxtBox11
            // 
            this.TxtBox11.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TxtBox11.Location = new System.Drawing.Point(278, 258);
            this.TxtBox11.Name = "TxtBox11";
            this.TxtBox11.Size = new System.Drawing.Size(63, 26);
            this.TxtBox11.TabIndex = 33;
            this.TxtBox11.Text = "0";
            this.TxtBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TxtBox11.Validated += new System.EventHandler(this.Validated);
            // 
            // TxtBox7
            // 
            this.TxtBox7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TxtBox7.Location = new System.Drawing.Point(278, 140);
            this.TxtBox7.Name = "TxtBox7";
            this.TxtBox7.Size = new System.Drawing.Size(63, 26);
            this.TxtBox7.TabIndex = 32;
            this.TxtBox7.Text = "0";
            this.TxtBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TxtBox7.Validated += new System.EventHandler(this.Validated);
            // 
            // Burger_6
            // 
            this.Burger_6.AutoSize = true;
            this.Burger_6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Burger_6.Location = new System.Drawing.Point(6, 287);
            this.Burger_6.Name = "Burger_6";
            this.Burger_6.Size = new System.Drawing.Size(225, 23);
            this.Burger_6.TabIndex = 5;
            this.Burger_6.Text = "Chicken Tandoor Grill - R160";
            this.Burger_6.UseVisualStyleBackColor = true;
            this.Burger_6.CheckedChanged += new System.EventHandler(this.Burger_6_CheckedChanged);
            // 
            // Burger_5
            // 
            this.Burger_5.AutoSize = true;
            this.Burger_5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Burger_5.Location = new System.Drawing.Point(6, 258);
            this.Burger_5.Name = "Burger_5";
            this.Burger_5.Size = new System.Drawing.Size(225, 23);
            this.Burger_5.TabIndex = 4;
            this.Burger_5.Text = "Chicken Chilli Cheese - R160";
            this.Burger_5.UseVisualStyleBackColor = true;
            this.Burger_5.CheckedChanged += new System.EventHandler(this.Burger_5_CheckedChanged);
            // 
            // Burger_4
            // 
            this.Burger_4.AutoSize = true;
            this.Burger_4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Burger_4.Location = new System.Drawing.Point(6, 229);
            this.Burger_4.Name = "Burger_4";
            this.Burger_4.Size = new System.Drawing.Size(233, 23);
            this.Burger_4.TabIndex = 3;
            this.Burger_4.Text = "Grilled Chicken Burger - R150";
            this.Burger_4.UseVisualStyleBackColor = true;
            this.Burger_4.CheckedChanged += new System.EventHandler(this.Burger_4_CheckedChanged);
            // 
            // Burger_3
            // 
            this.Burger_3.AutoSize = true;
            this.Burger_3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Burger_3.Location = new System.Drawing.Point(6, 200);
            this.Burger_3.Name = "Burger_3";
            this.Burger_3.Size = new System.Drawing.Size(196, 23);
            this.Burger_3.TabIndex = 2;
            this.Burger_3.Text = "Veg Chilli Cheese - R100";
            this.Burger_3.UseVisualStyleBackColor = true;
            this.Burger_3.CheckedChanged += new System.EventHandler(this.Burger_3_CheckedChanged);
            // 
            // Burger_2
            // 
            this.Burger_2.AutoSize = true;
            this.Burger_2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Burger_2.Location = new System.Drawing.Point(6, 171);
            this.Burger_2.Name = "Burger_2";
            this.Burger_2.Size = new System.Drawing.Size(160, 23);
            this.Burger_2.TabIndex = 1;
            this.Burger_2.Text = "Veg Surprise: - R80";
            this.Burger_2.UseVisualStyleBackColor = true;
            this.Burger_2.CheckedChanged += new System.EventHandler(this.Burger_2_CheckedChanged);
            // 
            // Burger_1
            // 
            this.Burger_1.AutoSize = true;
            this.Burger_1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Burger_1.Location = new System.Drawing.Point(6, 142);
            this.Burger_1.Name = "Burger_1";
            this.Burger_1.Size = new System.Drawing.Size(166, 23);
            this.Burger_1.TabIndex = 0;
            this.Burger_1.Text = "Veggie Burger - R65";
            this.Burger_1.UseVisualStyleBackColor = true;
            this.Burger_1.CheckedChanged += new System.EventHandler(this.Burger_1_CheckedChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(99, 31);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(134, 103);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // Drinks
            // 
            this.Drinks.BackColor = System.Drawing.Color.OrangeRed;
            this.Drinks.Controls.Add(this.Qty3);
            this.Drinks.Controls.Add(this.TxtBox14);
            this.Drinks.Controls.Add(this.TxtBox15);
            this.Drinks.Controls.Add(this.TxtBox16);
            this.Drinks.Controls.Add(this.TxtBox18);
            this.Drinks.Controls.Add(this.TxtBox17);
            this.Drinks.Controls.Add(this.TxtBox13);
            this.Drinks.Controls.Add(this.Beverage_6);
            this.Drinks.Controls.Add(this.Beverage_5);
            this.Drinks.Controls.Add(this.Beverage_4);
            this.Drinks.Controls.Add(this.Beverage_3);
            this.Drinks.Controls.Add(this.Beverage_2);
            this.Drinks.Controls.Add(this.Beverage_1);
            this.Drinks.Controls.Add(this.pictureBox2);
            this.Drinks.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Drinks.Location = new System.Drawing.Point(397, 43);
            this.Drinks.Name = "Drinks";
            this.Drinks.Size = new System.Drawing.Size(363, 321);
            this.Drinks.TabIndex = 7;
            this.Drinks.TabStop = false;
            this.Drinks.Text = "Beverages:";
            // 
            // Qty3
            // 
            this.Qty3.AutoSize = true;
            this.Qty3.Location = new System.Drawing.Point(286, 97);
            this.Qty3.Name = "Qty3";
            this.Qty3.Size = new System.Drawing.Size(50, 24);
            this.Qty3.TabIndex = 44;
            this.Qty3.Text = "Qty:";
            // 
            // TxtBox14
            // 
            this.TxtBox14.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TxtBox14.Location = new System.Drawing.Point(286, 168);
            this.TxtBox14.Name = "TxtBox14";
            this.TxtBox14.Size = new System.Drawing.Size(67, 26);
            this.TxtBox14.TabIndex = 43;
            this.TxtBox14.Text = "0";
            this.TxtBox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TxtBox14.Validated += new System.EventHandler(this.Validated);
            // 
            // TxtBox15
            // 
            this.TxtBox15.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TxtBox15.Location = new System.Drawing.Point(286, 197);
            this.TxtBox15.Name = "TxtBox15";
            this.TxtBox15.Size = new System.Drawing.Size(67, 26);
            this.TxtBox15.TabIndex = 42;
            this.TxtBox15.Text = "0";
            this.TxtBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TxtBox15.Validated += new System.EventHandler(this.Validated);
            // 
            // TxtBox16
            // 
            this.TxtBox16.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TxtBox16.Location = new System.Drawing.Point(286, 226);
            this.TxtBox16.Name = "TxtBox16";
            this.TxtBox16.Size = new System.Drawing.Size(67, 26);
            this.TxtBox16.TabIndex = 41;
            this.TxtBox16.Text = "0";
            this.TxtBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TxtBox16.Validated += new System.EventHandler(this.Validated);
            // 
            // TxtBox18
            // 
            this.TxtBox18.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TxtBox18.Location = new System.Drawing.Point(286, 285);
            this.TxtBox18.Name = "TxtBox18";
            this.TxtBox18.Size = new System.Drawing.Size(67, 26);
            this.TxtBox18.TabIndex = 40;
            this.TxtBox18.Text = "0";
            this.TxtBox18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TxtBox18.Validated += new System.EventHandler(this.Validated);
            // 
            // TxtBox17
            // 
            this.TxtBox17.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TxtBox17.Location = new System.Drawing.Point(286, 255);
            this.TxtBox17.Name = "TxtBox17";
            this.TxtBox17.Size = new System.Drawing.Size(67, 26);
            this.TxtBox17.TabIndex = 39;
            this.TxtBox17.Text = "0";
            this.TxtBox17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TxtBox17.Validated += new System.EventHandler(this.Validated);
            // 
            // TxtBox13
            // 
            this.TxtBox13.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TxtBox13.Location = new System.Drawing.Point(286, 137);
            this.TxtBox13.Name = "TxtBox13";
            this.TxtBox13.Size = new System.Drawing.Size(67, 26);
            this.TxtBox13.TabIndex = 38;
            this.TxtBox13.Text = "0";
            this.TxtBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TxtBox13.Validated += new System.EventHandler(this.Validated);
            // 
            // Beverage_6
            // 
            this.Beverage_6.AutoSize = true;
            this.Beverage_6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Beverage_6.Location = new System.Drawing.Point(6, 287);
            this.Beverage_6.Name = "Beverage_6";
            this.Beverage_6.Size = new System.Drawing.Size(165, 23);
            this.Beverage_6.TabIndex = 5;
            this.Beverage_6.Text = "Hot Chocolate - R17";
            this.Beverage_6.UseVisualStyleBackColor = true;
            this.Beverage_6.CheckedChanged += new System.EventHandler(this.Beverage_6_CheckedChanged);
            // 
            // Beverage_5
            // 
            this.Beverage_5.AutoSize = true;
            this.Beverage_5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Beverage_5.Location = new System.Drawing.Point(6, 258);
            this.Beverage_5.Name = "Beverage_5";
            this.Beverage_5.Size = new System.Drawing.Size(171, 23);
            this.Beverage_5.TabIndex = 4;
            this.Beverage_5.Text = "Ice Cappuccino - R17";
            this.Beverage_5.UseVisualStyleBackColor = true;
            this.Beverage_5.CheckedChanged += new System.EventHandler(this.Beverage_5_CheckedChanged);
            // 
            // Beverage_4
            // 
            this.Beverage_4.AutoSize = true;
            this.Beverage_4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Beverage_4.Location = new System.Drawing.Point(6, 229);
            this.Beverage_4.Name = "Beverage_4";
            this.Beverage_4.Size = new System.Drawing.Size(146, 23);
            this.Beverage_4.TabIndex = 3;
            this.Beverage_4.Text = "Cappuccino - R25";
            this.Beverage_4.UseVisualStyleBackColor = true;
            this.Beverage_4.CheckedChanged += new System.EventHandler(this.Beverage_4_CheckedChanged);
            // 
            // Beverage_3
            // 
            this.Beverage_3.AutoSize = true;
            this.Beverage_3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Beverage_3.Location = new System.Drawing.Point(6, 200);
            this.Beverage_3.Name = "Beverage_3";
            this.Beverage_3.Size = new System.Drawing.Size(189, 23);
            this.Beverage_3.TabIndex = 2;
            this.Beverage_3.Text = "500 ML Still Water - R8";
            this.Beverage_3.UseVisualStyleBackColor = true;
            this.Beverage_3.CheckedChanged += new System.EventHandler(this.Beverage_3_CheckedChanged);
            // 
            // Beverage_2
            // 
            this.Beverage_2.AutoSize = true;
            this.Beverage_2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Beverage_2.Location = new System.Drawing.Point(6, 171);
            this.Beverage_2.Name = "Beverage_2";
            this.Beverage_2.Size = new System.Drawing.Size(230, 23);
            this.Beverage_2.TabIndex = 1;
            this.Beverage_2.Text = "500 ML flavoured water - R15";
            this.Beverage_2.UseVisualStyleBackColor = true;
            this.Beverage_2.CheckedChanged += new System.EventHandler(this.Beverage_2_CheckedChanged);
            // 
            // Beverage_1
            // 
            this.Beverage_1.AutoSize = true;
            this.Beverage_1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Beverage_1.Location = new System.Drawing.Point(6, 142);
            this.Beverage_1.Name = "Beverage_1";
            this.Beverage_1.Size = new System.Drawing.Size(195, 23);
            this.Beverage_1.TabIndex = 0;
            this.Beverage_1.Text = "500 ML Coca Cola - R25";
            this.Beverage_1.UseVisualStyleBackColor = true;
            this.Beverage_1.CheckedChanged += new System.EventHandler(this.Beverage_1_CheckedChanged);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.White;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(102, 33);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(134, 103);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            // 
            // Btn_Reset
            // 
            this.Btn_Reset.BackColor = System.Drawing.Color.YellowGreen;
            this.Btn_Reset.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Btn_Reset.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Reset.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Btn_Reset.Location = new System.Drawing.Point(551, 642);
            this.Btn_Reset.Name = "Btn_Reset";
            this.Btn_Reset.Size = new System.Drawing.Size(95, 31);
            this.Btn_Reset.TabIndex = 8;
            this.Btn_Reset.Text = "RESET";
            this.Btn_Reset.UseVisualStyleBackColor = false;
            this.Btn_Reset.Click += new System.EventHandler(this.Btn_Reset_Click);
            // 
            // Btn_PlaceOrder
            // 
            this.Btn_PlaceOrder.BackColor = System.Drawing.Color.YellowGreen;
            this.Btn_PlaceOrder.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Btn_PlaceOrder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_PlaceOrder.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Btn_PlaceOrder.Location = new System.Drawing.Point(421, 642);
            this.Btn_PlaceOrder.Name = "Btn_PlaceOrder";
            this.Btn_PlaceOrder.Size = new System.Drawing.Size(95, 31);
            this.Btn_PlaceOrder.TabIndex = 9;
            this.Btn_PlaceOrder.Text = "ORDER";
            this.Btn_PlaceOrder.UseVisualStyleBackColor = false;
            this.Btn_PlaceOrder.Click += new System.EventHandler(this.Btn_PlaceOrder_Click);
            // 
            // Lbl_Total
            // 
            this.Lbl_Total.AutoSize = true;
            this.Lbl_Total.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Lbl_Total.ForeColor = System.Drawing.Color.White;
            this.Lbl_Total.Location = new System.Drawing.Point(412, 570);
            this.Lbl_Total.Name = "Lbl_Total";
            this.Lbl_Total.Size = new System.Drawing.Size(65, 17);
            this.Lbl_Total.TabIndex = 10;
            this.Lbl_Total.Text = "TOTAL:";
            // 
            // tot_txtbox
            // 
            this.tot_txtbox.Enabled = false;
            this.tot_txtbox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.tot_txtbox.ForeColor = System.Drawing.Color.Black;
            this.tot_txtbox.Location = new System.Drawing.Point(508, 564);
            this.tot_txtbox.Name = "tot_txtbox";
            this.tot_txtbox.ReadOnly = true;
            this.tot_txtbox.Size = new System.Drawing.Size(263, 26);
            this.tot_txtbox.TabIndex = 11;
            // 
            // Btn_Exit
            // 
            this.Btn_Exit.BackColor = System.Drawing.Color.YellowGreen;
            this.Btn_Exit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Btn_Exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Exit.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Btn_Exit.Location = new System.Drawing.Point(673, 641);
            this.Btn_Exit.Name = "Btn_Exit";
            this.Btn_Exit.Size = new System.Drawing.Size(98, 31);
            this.Btn_Exit.TabIndex = 12;
            this.Btn_Exit.Text = "EXIT";
            this.Btn_Exit.UseVisualStyleBackColor = false;
            this.Btn_Exit.Click += new System.EventHandler(this.Btn_Exit_Click);
            // 
            // Receipt
            // 
            this.Receipt.BackColor = System.Drawing.Color.White;
            this.Receipt.Location = new System.Drawing.Point(777, 43);
            this.Receipt.Name = "Receipt";
            this.Receipt.Size = new System.Drawing.Size(368, 637);
            this.Receipt.TabIndex = 13;
            this.Receipt.Text = "";
            // 
            // tax_txtbox
            // 
            this.tax_txtbox.Enabled = false;
            this.tax_txtbox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.tax_txtbox.ForeColor = System.Drawing.Color.Black;
            this.tax_txtbox.Location = new System.Drawing.Point(508, 481);
            this.tax_txtbox.Name = "tax_txtbox";
            this.tax_txtbox.ReadOnly = true;
            this.tax_txtbox.Size = new System.Drawing.Size(263, 26);
            this.tax_txtbox.TabIndex = 15;
            // 
            // Tax_Lbl
            // 
            this.Tax_Lbl.AutoSize = true;
            this.Tax_Lbl.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Tax_Lbl.ForeColor = System.Drawing.Color.White;
            this.Tax_Lbl.Location = new System.Drawing.Point(412, 485);
            this.Tax_Lbl.Name = "Tax_Lbl";
            this.Tax_Lbl.Size = new System.Drawing.Size(45, 19);
            this.Tax_Lbl.TabIndex = 14;
            this.Tax_Lbl.Text = "TAX:";
            // 
            // subtot_txtbox
            // 
            this.subtot_txtbox.Enabled = false;
            this.subtot_txtbox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.subtot_txtbox.ForeColor = System.Drawing.Color.Black;
            this.subtot_txtbox.Location = new System.Drawing.Point(508, 519);
            this.subtot_txtbox.Name = "subtot_txtbox";
            this.subtot_txtbox.ReadOnly = true;
            this.subtot_txtbox.Size = new System.Drawing.Size(263, 26);
            this.subtot_txtbox.TabIndex = 17;
            // 
            // Subtotal_lbl
            // 
            this.Subtotal_lbl.AutoSize = true;
            this.Subtotal_lbl.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Subtotal_lbl.ForeColor = System.Drawing.Color.White;
            this.Subtotal_lbl.Location = new System.Drawing.Point(412, 525);
            this.Subtotal_lbl.Name = "Subtotal_lbl";
            this.Subtotal_lbl.Size = new System.Drawing.Size(95, 17);
            this.Subtotal_lbl.TabIndex = 16;
            this.Subtotal_lbl.Text = "SUBTOTAL:";
            // 
            // menuform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1145, 686);
            this.Controls.Add(this.subtot_txtbox);
            this.Controls.Add(this.Subtotal_lbl);
            this.Controls.Add(this.tax_txtbox);
            this.Controls.Add(this.Tax_Lbl);
            this.Controls.Add(this.Receipt);
            this.Controls.Add(this.Btn_Exit);
            this.Controls.Add(this.tot_txtbox);
            this.Controls.Add(this.Lbl_Total);
            this.Controls.Add(this.Btn_PlaceOrder);
            this.Controls.Add(this.Btn_Reset);
            this.Controls.Add(this.Drinks);
            this.Controls.Add(this.Burgers);
            this.Controls.Add(this.Sandwich);
            this.Controls.Add(this.TopPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "menuform";
            this.Text = "menuform";
            this.Load += new System.EventHandler(this.menuform_Load);
            this.TopPanel.ResumeLayout(false);
            this.TopPanel.PerformLayout();
            this.Sandwich.ResumeLayout(false);
            this.Sandwich.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Sandwich_Box)).EndInit();
            this.Burgers.ResumeLayout(false);
            this.Burgers.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.Drinks.ResumeLayout(false);
            this.Drinks.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Panel TopPanel;
        private GroupBox Sandwich;
        private CheckBox Sandwich_6;
        private CheckBox Sandwich_5;
        private CheckBox Sandwich_4;
        private CheckBox Sandwich_3;
        private CheckBox Sandwich_2;
        private CheckBox Sandwich_1;
        private PictureBox Sandwich_Box;
        private GroupBox Burgers;
        private CheckBox Burger_6;
        private CheckBox Burger_5;
        private CheckBox Burger_4;
        private CheckBox Burger_3;
        private CheckBox Burger_2;
        private CheckBox Burger_1;
        private PictureBox pictureBox1;
        private GroupBox Drinks;
        private CheckBox Beverage_6;
        private CheckBox Beverage_5;
        private CheckBox Beverage_4;
        private CheckBox Beverage_3;
        private CheckBox Beverage_2;
        private CheckBox Beverage_1;
        private PictureBox pictureBox2;
        private TextBox TxtBox2;
        private TextBox TxtBox3;
        private TextBox TxtBox4;
        private TextBox TxtBox6;
        private TextBox TxtBox5;
        private TextBox TxtBox1;
        private TextBox TxtBox8;
        private TextBox TxtBox9;
        private TextBox TxtBox10;
        private TextBox TxtBox12;
        private TextBox TxtBox11;
        private TextBox TxtBox7;
        private TextBox TxtBox14;
        private TextBox TxtBox15;
        private TextBox TxtBox16;
        private TextBox TxtBox18;
        private TextBox TxtBox17;
        private TextBox TxtBox13;
        private Label Qty1;
        private Label Qty2;
        private Label Qty3;
        private Button Btn_Reset;
        private Button Btn_PlaceOrder;
        private Label Lbl_Total;
        private TextBox tot_txtbox;
        private Button Btn_Exit;
        private RichTextBox Receipt;
        private TextBox tax_txtbox;
        private Label Tax_Lbl;
        private TextBox subtot_txtbox;
        private Label Subtotal_lbl;
        private Label BC_Cafe_Lbl;
    }
}