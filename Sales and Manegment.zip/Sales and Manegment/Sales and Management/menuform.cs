﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Milestone_2_PRG281
{
    public partial class menuform : Form
    {
        public menuform()
        {
            InitializeComponent();
        }

        private void Sandwich_Enter(object sender, EventArgs e)
        {

        }
        private void Btn_Exit_Click(object sender, EventArgs e)
        {
            DialogResult iexit;
            iexit = MessageBox.Show("Do you want to exit?", "BC Cafe", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (iexit == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
        private void EnableTextBoxes()
        {
            Action<Control.ControlCollection> func = null;
            func = (controls) =>
            {
                foreach (Control control in controls) 
                {
                    if (control is TextBox)
                    {
                        (control as TextBox).Enabled = false;
                    }
                    else
                    {
                        func(control.Controls);
                    }              
                                   
                }
            };
            func(Controls);
        }
        private void ClearTextBoxes()
        {
            Action<Control.ControlCollection> func = null;
            func = (controls) =>
            {
                foreach (Control control in controls)
                {
                    if (control is TextBox)
                    {
                        (control as TextBox).Text = "0";
                    }
                    else
                    {
                        func(control.Controls);
                    }                                                         
                }
            };
            func(Controls);
        }
        private void ResetCheckBoxes()
        {
            Action<Control.ControlCollection> func = null;
            func = (controls) =>
            {
                foreach (Control control in controls)
                {
                    if (control is CheckBox)
                    {
                        (control as CheckBox).Checked = false;
                    }
                    else
                    {
                        func(control.Controls);
                    }                                                       
                }
            };
            func(Controls);
        }     
        private void Btn_Reset_Click(object sender, EventArgs e)
        {
            EnableTextBoxes();
            ResetCheckBoxes();
            ClearTextBoxes();

            tax_txtbox.Text = "";
            subtot_txtbox.Text = "";
            tot_txtbox.Text = "";
            Receipt.Clear();
        }

        private void menuform_Load(object sender, EventArgs e)
        {
            EnableTextBoxes();
            ResetCheckBoxes();
            ClearTextBoxes();
            Receipt.Clear();
        }

        private void Btn_PlaceOrder_Click(object sender, EventArgs e)
        {
            FoodItem1 FooditemValue = new FoodItem1();

            double ItemTax, ItemSubtotal, ItemTotal;

            FooditemValue.ToastedCheese = FooditemValue.ToastedCheese_Value * double.Parse(TxtBox1.Text);
            FooditemValue.ToastedCheeseAndTomato = FooditemValue.ToastedCheeseAndTomato_Value * double.Parse(TxtBox2.Text);
            FooditemValue.ToastedHamAndCheese = FooditemValue.ToastedHamAndCheese_Value * double.Parse(TxtBox3.Text);
            FooditemValue.GarlicCheeseToast = FooditemValue.GarlicCheeseToast_Value * double.Parse(TxtBox4.Text);
            FooditemValue.ToastedChickenMayo = FooditemValue.ToastedChickenMayo_Value * double.Parse(TxtBox5.Text);
            FooditemValue.SupremeToast = FooditemValue.SupremeToast_Value * double.Parse(TxtBox6.Text);

            FooditemValue.VeggieBurger = FooditemValue.VeggieBurger_Value * double.Parse(TxtBox7.Text);
            FooditemValue.VegSurprise = FooditemValue.VegSurprise_Value * double.Parse(TxtBox8.Text);
            FooditemValue.VegChilliCheese = FooditemValue.VegChilliCheese_Value * double.Parse(TxtBox9.Text);
            FooditemValue.GrilledChickenBurger = FooditemValue.GrilledChickenBurger_Value * double.Parse(TxtBox10.Text);  
            FooditemValue.ChickenChilliCheese = FooditemValue.ChickenChilliCheese_Value * double.Parse (TxtBox11.Text);
            FooditemValue.ChickenTandoorGrill = FooditemValue.ChickenTandoorGrill_Value * double.Parse(TxtBox12.Text);

            FooditemValue.CocaCola = FooditemValue.CocaCola_Value * double.Parse(TxtBox13.Text);
            FooditemValue.FlavouredWater = FooditemValue.FlavouredWater_Value * double.Parse(TxtBox14.Text);
            FooditemValue.StillWater = FooditemValue.StillWater_Value * double.Parse(TxtBox15.Text);
            FooditemValue.Cappuccino = FooditemValue.Cappuccino_Value * double.Parse(TxtBox16.Text);
            FooditemValue.IceCappuccino = FooditemValue.IceCappuccino_Value * double.Parse(TxtBox17.Text);
            FooditemValue.HotChocolate = FooditemValue.HotChocolate_Value * double.Parse(TxtBox18.Text);

           
            ItemSubtotal = FooditemValue.GetValue();
            ItemTax = FooditemValue.getTax();
            ItemTotal = ItemTax + ItemSubtotal;
          
            subtot_txtbox.Text = String.Format("{0:C}", ItemSubtotal);
            tax_txtbox.Text = String.Format("{0:C}", ItemTax);
            tot_txtbox.Text = String.Format("{0:C}", ItemTotal);

            Console.WriteLine("-----------------Receipt------------------");

            Receipt.AppendText("\t\t\tBC Cafe\n------------------------------------------------------------------------\n" + 
                "====================Sandwiches=================" +

                "Toasted Cheese:\t\t\t\t"+ TxtBox1.Text + "\n" +
                "Toasted Cheese and Tomato:\t\t"+ TxtBox2.Text + "\n" +
                "Toasted Ham and Cheese:\t\t\t"+ TxtBox3.Text + "\n" +
                "Garlic Cheese Toast:\t\t\t"+ TxtBox4.Text + "\n" +
                "Toasted Chicken Mayo:\t\t\t"+ TxtBox5.Text + "\n" +
                "Supreme Toast:\t\t\t\t"+ TxtBox6.Text + "\n" +

                "=====================Burgers===================" +

                "Veggie Burger:\t\t\t\t"+ TxtBox7.Text + "\n" +
                "Veg Surprise:\t\t\t\t"+ TxtBox8.Text + "\n" +
                "Veg Chilli Cheese:\t\t\t\t"+ TxtBox9.Text + "\n" +
                "Grilled Chicken Burger:\t\t\t"+ TxtBox10.Text + "\n"+
                "Chicken Chilli Cheese:\t\t\t"+ TxtBox11.Text + "\n" +
                "Chicken Tandoor Grill:\t\t\t"+ TxtBox12.Text + "\n" +

                "=====================Beverages=================" +

                "500 ML CocaCola:\t\t\t\t"+ TxtBox13.Text + "\n" +
                "500 ML Flavoured Water:\t\t\t"+ TxtBox14.Text + "\n" +
                "500 ML Still Water:\t\t\t"+ TxtBox15.Text + "\n" +
                "Cappuccino:\t\t\t\t"+ TxtBox16.Text + "\n" +
                "Ice Cappuccino:\t\t\t\t"+ TxtBox17.Text + "\n" +
                "Hot Chocolate:\t\t\t\t"+ TxtBox18.Text
                );


        }

        private void Sandwich_1_CheckedChanged(object sender, EventArgs e)
        {
            if(Sandwich_1.Checked == true)
            {
                TxtBox1.Text = "";
                TxtBox1.Enabled = true;
                TxtBox1.Focus();
            }
            else
            {
                TxtBox1.Text = "0";
                TxtBox1.Enabled = false;
            }
        }

        private void Sandwich_2_CheckedChanged(object sender, EventArgs e)
        {
            if (Sandwich_2.Checked == true)
            {
                TxtBox2.Text = "";
                TxtBox2.Enabled = true;
                TxtBox2.Focus();
            }
            else
            {
                TxtBox2.Text = "0";
                TxtBox2.Enabled = false;
            }
        }

        private void Sandwich_3_CheckedChanged(object sender, EventArgs e)
        {
            if (Sandwich_3.Checked == true)
            {
                TxtBox3.Text = "";
                TxtBox3.Enabled = true;
                TxtBox3.Focus();
            }
            else
            {
                TxtBox3.Text = "0";
                TxtBox3.Enabled = false;
            }
        }

        private void Sandwich_4_CheckedChanged(object sender, EventArgs e)
        {
            if (Sandwich_4.Checked == true)
            {
                TxtBox4.Text = "";
                TxtBox4.Enabled = true;
                TxtBox4.Focus();
            }
            else
            {
                TxtBox4.Text = "0";
                TxtBox4.Enabled = false;
           
            }
        }

        private void Sandwich_5_CheckedChanged(object sender, EventArgs e)
        {
            if (Sandwich_5.Checked == true)
            {
                TxtBox5.Text = "";
                TxtBox5.Enabled = true;
                TxtBox5.Focus();
            }
            else
            {
                TxtBox5.Text = "0";
                TxtBox5.Enabled = false;

            }
        }

        private void Sandwich_6_CheckedChanged(object sender, EventArgs e)
        {
            if (Sandwich_6.Checked == true)
            {
                TxtBox6.Text = "";
                TxtBox6.Enabled = true;
                TxtBox6.Focus();
            }
            else
            {
                TxtBox6.Text = "0";
                TxtBox6.Enabled = false;

            }
        }

        private void Burger_1_CheckedChanged(object sender, EventArgs e)
        {
            if (Burger_1.Checked == true)
            {
                TxtBox7.Text = "";
                TxtBox7.Enabled = true;
                TxtBox7.Focus();
            }
            else
            {
                TxtBox7.Text = "0";
                TxtBox7.Enabled = false;

            }
        }

        private void Burger_2_CheckedChanged(object sender, EventArgs e)
        {
            if (Burger_2.Checked == true)
            {
                TxtBox8.Text = "";
                TxtBox8.Enabled = true;
                TxtBox8.Focus();
            }
            else
            {
                TxtBox8.Text = "0";
                TxtBox8.Enabled = false;

            }
        }

        private void Burger_3_CheckedChanged(object sender, EventArgs e)
        {
            if (Burger_3.Checked == true)
            {
                TxtBox9.Text = "";
                TxtBox9.Enabled = true;
                TxtBox9.Focus();
            }
            else
            {
                TxtBox9.Text = "0";
                TxtBox9.Enabled = false;

            }
        }

        private void Burger_4_CheckedChanged(object sender, EventArgs e)
        {
            if (Burger_4.Checked == true)
            {
                TxtBox10.Text = "";
                TxtBox10.Enabled = true;
                TxtBox10.Focus();
            }
            else
            {
                TxtBox10.Text = "0";
                TxtBox10.Enabled = false;

            }
        }

        private void Burger_5_CheckedChanged(object sender, EventArgs e)
        {
            if (Burger_5.Checked == true)
            {
                TxtBox11.Text = "";
                TxtBox11.Enabled = true;
                TxtBox11.Focus();
            }
            else
            {
                TxtBox11.Text = "0";
                TxtBox11.Enabled = false;

            }
        }

        private void Burger_6_CheckedChanged(object sender, EventArgs e)
        {
            if (Burger_6.Checked == true)
            {
                TxtBox12.Text = "";
                TxtBox12.Enabled = true;
                TxtBox12.Focus();
            }
            else
            {
                TxtBox12.Text = "0";
                TxtBox12.Enabled = false;

            }
        }

        private void Beverage_1_CheckedChanged(object sender, EventArgs e)
        {
            if (Beverage_1.Checked == true)
            {
                TxtBox13.Text = "";
                TxtBox13.Enabled = true;
                TxtBox13.Focus();
            }
            else
            {
                TxtBox13.Text = "0";
                TxtBox13.Enabled = false;

            }
        }
        private void Beverage_2_CheckedChanged(object sender, EventArgs e)
        {
            if (Beverage_2.Checked == true)
            {
                TxtBox14.Text = "";
                TxtBox14.Enabled = true;
                TxtBox14.Focus();
            }
            else
            {
                TxtBox14.Text = "0";
                TxtBox14.Enabled = false;

            }
        }

        private void Beverage_3_CheckedChanged(object sender, EventArgs e)
        {
            if (Beverage_3.Checked == true)
            {
                TxtBox15.Text = "";
                TxtBox15.Enabled = true;
                TxtBox15.Focus();
            }
            else
            {
                TxtBox15.Text = "0";
                TxtBox15.Enabled = false;

            }
        }
        private void Beverage_4_CheckedChanged(object sender, EventArgs e)
        {
            if (Beverage_4.Checked == true)
            {
                TxtBox16.Text = "";
                TxtBox16.Enabled = true;
                TxtBox16.Focus();
            }
            else
            {
                TxtBox16.Text = "0";
                TxtBox16.Enabled = false;

            }
        }
        private void Beverage_5_CheckedChanged(object sender, EventArgs e)
        {
            if (Beverage_5.Checked == true)
            {
                TxtBox17.Text = "";
                TxtBox17.Enabled = true;
                TxtBox17.Focus();
            }
            else
            {
                TxtBox17.Text = "0";
                TxtBox17.Enabled = false;

            }
        }
        private void Beverage_6_CheckedChanged(object sender, EventArgs e)
        {
            if (Beverage_6.Checked == true)
            {
                TxtBox18.Text = "";
                TxtBox18.Enabled = true;
                TxtBox18.Focus();
            }
            else
            {
                TxtBox18.Text = "0";
                TxtBox18.Enabled = false;

            }
        }

        private void Validated(object sender, EventArgs e)
        {
            TextBox text = sender as TextBox;
            
            if(text.Text == "")
            {
                text.Text = "0";
            }


        }
    }  
}
