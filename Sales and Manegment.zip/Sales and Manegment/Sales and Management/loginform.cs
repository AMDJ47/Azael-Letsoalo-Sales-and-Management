namespace Milestone_2_PRG281
{
    public partial class loginform : Form
    {
        public loginform()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
         
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string password1 ="Student@BelgiumCampus";
            string user1 = "Student";

            string password2 = "BC@Cafe";
            string user2 = "Owner";

            if (textBox3.Text==user1 && textBox2.Text==password1)
            {
                MessageBox.Show("Yippy, You Are In :')");
                this.Hide();
                Form2 form2 = new Form2();
                form2.ShowDialog(); 
            }            
            else if (textBox3.Text == user2 && textBox2.Text == password2)
            {
                MessageBox.Show("Yippy, You Are In :')");
                this.Hide();
                Admin_Dashboard Dashboard = new Admin_Dashboard();
                Dashboard.ShowDialog();
            }
            else
            {
                MessageBox.Show("Login unsuccessfull, please try again.");
            }
        }
    }
}