﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Milestone_2_PRG281
{
    internal class FoodItems
    {
        public double ToastedCheese;
        public double ToastedCheeseAndTomato;
        public double ToastedHamAndCheese;
        public double GarlicCheeseToast;
        public double ToastedChickenMayo;
        public double SupremeToast;
        public double VeggieBurger;
        public double VegSurprise;
        public double VegChilliCheese;
        public double GrilledChickenBurger;
        public double ChickenChilliCheese;
        public double ChickenTandoorGrill;
        public double CocaCola;
        public double FlavouredWater;
        public double StillWater;
        public double Cappuccino;
        public double IceCappuccino;
        public double HotChocolate;
        public double Tax = 0.12;

        public double ToastedCheese_Value = 29.99;
        public double ToastedCheeseAndTomato_Value = 39.99;
        public double ToastedHamAndCheese_Value = 39.99;
        public double GarlicCheeseToast_Value = 34.99;
        public double ToastedChickenMayo_Value = 49.99;
        public double SupremeToast_Value = 54.99;
        public double VeggieBurger_Value = 64.99;
        public double VegSurprise_Value = 79.99;
        public double VegChilliCheese_Value = 99.99;
        public double GrilledChickenBurger_Value = 149.99;
        public double ChickenChilliCheese_Value = 159.99;
        public double ChickenTandoorGrill_Value = 159.99;
        public double CocaCola_Value = 24.99;
        public double FlavouredWater_Value = 14.99;
        public double StillWater_Value = 7.99;
        public double Cappuccino_Value = 24.99;
        public double IceCappuccino_Value = 16.99;
        public double HotChocolate_Value = 16.99;

        public double itemCost1;
        public double itemCost2;    
        public double itemCost3;  
        public double itemCost;
        public double Tax_Value;

        public double GetValue()
        {
            itemCost1 = ToastedCheese + ToastedCheeseAndTomato + ToastedHamAndCheese + GarlicCheeseToast + ToastedChickenMayo + SupremeToast;
            itemCost2 = VeggieBurger + VegSurprise + VegChilliCheese + GrilledChickenBurger + ChickenChilliCheese + ChickenTandoorGrill;
            itemCost3 = CocaCola + FlavouredWater + StillWater + Cappuccino + IceCappuccino + HotChocolate;

            itemCost = itemCost1 + itemCost2 + itemCost3;
  
            return itemCost;
        }

        public double TaxRate(double Amount)
        {
            double tax = (Amount * Tax);
            return tax;
        }
        public double getTax()
        {
            Tax_Value = TaxRate(itemCost);
            return Tax_Value;   
        }

    }

}
