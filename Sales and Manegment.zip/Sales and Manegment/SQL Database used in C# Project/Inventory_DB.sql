
--Database creation for usage in c# project
create database Inventory

--Table creation for use in c# project
use Inventory
create table Inventorytable
(
ItemID int primary key identity(1,1),
ItemCategory varchar(50),
ItemName varchar(50),
Quantity int,
Price int
)

--Test
select * from Inventorytable
